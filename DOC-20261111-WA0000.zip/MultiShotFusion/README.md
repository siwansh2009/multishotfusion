# MultiShot Fusion

Offline multi-camera photography for Android (Expo SDK 52 + React Native + custom dev client).

Detects logical and physical rear cameras via Camera2, captures from multiple physical
cameras **simultaneously** where the hardware/HAL supports it (one logical camera, one
capture request, N physical-bound surfaces — never faked), falls back to sequential
capture otherwise (always reported truthfully), and merges frames locally:
panorama stitch / composite / grid.

## Why a development build?
Expo Go's `expo-camera` exposes no physical camera IDs and only one preview, so the
camera core ships as a native Kotlin module (`native-android/...`), auto-installed by
`plugins/withMultiShotFusion.js` during prebuild:

    npm install
    npx expo prebuild            # installs Kotlin module + permissions
    npx expo run:android         # dev client (NOT Expo Go)

## Tests
    npm test    # 8 unit tests for the alignment/blending engine (pure Node)

## Honest status
Kotlin compilation, `expo prebuild` execution, Metro bundling and all on-device
behavior are UNTESTED — see the conversation report. No Android compilation is
claimed.

## Ads (optional)
Set `expo.extra.admob.enabled=true` + a real `bannerUnitId` in app.json. Ads are
opt-in, off by default, and never shown during capture or processing.

## Privacy
No accounts, no backend, no analytics, fully offline. Photos stay in app-private
storage; gallery import is opt-in per capture.
