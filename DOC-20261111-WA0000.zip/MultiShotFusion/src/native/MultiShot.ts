
import { NativeModules, Platform } from 'react-native';

export interface PhysicalCameraInfo {
  id: string;
  facing: 'front' | 'back' | 'external';
  logical: boolean;
  supportsConcurrent: boolean;
  physicalIds: string[];
  focalLengths: number[];
}

export type MergeMode = 'panorama' | 'composite' | 'grid' | 'none';

export interface CaptureResult {
  mode: 'concurrent' | 'sequential';
  logicalCameraId: string;
  cameraIds: string[];
  originals: string[];
  merged: string | null;
  sessionDir: string;
}

export interface MultiShotNative {
  detectCameras(): Promise<PhysicalCameraInfo[]>;
  capture(options: { mergeMode: MergeMode; quality: number }): Promise<CaptureResult>;
  mergeImages(paths: string[], mode: Exclude<MergeMode, 'none'>): Promise<string>;
}

const native: MultiShotNative | null =
  Platform.OS === 'android' && NativeModules.MultiShotFusionModule
    ? NativeModules.MultiShotFusionModule
    : null;

export const isNativeCaptureAvailable = () => native !== null;

export async function detectCameras(): Promise<PhysicalCameraInfo[]> {
  if (!native) throw new Error('Native Camera2 module unavailable (dev build required)');
  return native.detectCameras();
}

export async function capture(options: { mergeMode: MergeMode; quality: number }): Promise<CaptureResult> {
  if (!native) throw new Error('Native Camera2 module unavailable (dev build required)');
  return native.capture(options);
}

export async function mergeImages(paths: string[], mode: Exclude<MergeMode, 'none'>): Promise<string> {
  if (!native) throw new Error('Native Camera2 module unavailable (dev build required)');
  return native.mergeImages(paths, mode);
}
