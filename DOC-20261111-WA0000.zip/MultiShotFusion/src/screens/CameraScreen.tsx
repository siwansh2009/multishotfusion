
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Screen, Chip, PrimaryButton } from '../ui/components';
import { colors, radius, spacing } from '../theme';
import * as MultiShot from '../native/MultiShot';
import type { MergeMode, PhysicalCameraInfo } from '../native/MultiShot';
import { recordCapture } from '../state/rolls';
import { useSettings } from '../state/settings';

type Phase = 'idle' | 'capturing' | 'processing';

export default function CameraScreen({ navigation }: any) {
  const [permission, requestPermission] = useCameraPermissions();
  const { settings } = useSettings();
  const [cameras, setCameras] = useState<PhysicalCameraInfo[]>([]);
  const [nativeReady, setNativeReady] = useState(MultiShot.isNativeCaptureAvailable());
  const [mergeMode, setMergeMode] = useState<Exclude<MergeMode, 'none'>>(settings.mergeMode);
  const [phase, setPhase] = useState<Phase>('idle');
  const [statusText, setStatusText] = useState('');
  const [concurrent, setConcurrent] = useState(false);
  const camRef = useRef<CameraView>(null);

  useEffect(() => {
    (async () => {
      if (!MultiShot.isNativeCaptureAvailable()) return;
      try {
        const list = await MultiShot.detectCameras();
        setCameras(list);
        const back = list.find((c) => c.facing === 'back') ?? list[0];
        setConcurrent(!!back?.supportsConcurrent);
      } catch (e: any) {
        setStatusText(`Camera detection failed: ${e?.message ?? e}`);
      }
    })();
  }, []);

  const shutter = useCallback(async () => {
    if (phase !== 'idle') return;
    if (!nativeReady) {
      // Honest Expo Go behavior: single-frame capture only, no fake multi-cam.
      try {
        const photo = await camRef.current?.takePictureAsync({ quality: settings.quality });
        if (photo) await recordCapture({ mode: 'sequential', logicalCameraId: 'expo', cameraIds: [], originals: [photo.uri], merged: null, sessionDir: '' }, { saveOriginals: true, saveToGallery: false });
      } catch { /* ignore */ }
      return;
    }
    setPhase('capturing');
    try {
      setStatusText('Acquiring cameras…');
      const result = await MultiShot.capture({ mergeMode, quality: settings.quality });
      setStatusText('Merging locally…');
      await recordCapture(result, { saveOriginals: settings.saveOriginals, saveToGallery: settings.saveToGallery });
      setStatusText(`Saved (${result.mode} capture, ${result.cameraIds.length} cameras)`);
    } catch (e: any) {
      setStatusText(`Capture failed: ${e?.message ?? e}`);
    } finally {
      setPhase('idle');
    }
  }, [phase, nativeReady, mergeMode, settings]);

  if (!permission) return <Screen title="Camera"><View /></Screen>;
  if (!permission.granted) {
    return (
      <Screen title="Camera">
        <View style={styles.center}>
          <Text style={styles.dim}>Camera permission is required to capture photos.</Text>
          <PrimaryButton label="Grant permission" onPress={requestPermission} />
        </View>
      </Screen>
    );
  }

  const backCams = cameras.filter((c) => c.facing === 'back');

  return (
    <Screen title="MultiShot Fusion" right={<Chip label={concurrent ? '● MULTI-CAM' : 'SINGLE-CAM'} active={concurrent} />}>
      {/* Preview from expo-camera (logical back camera). During capture the view
          unmounts so the native module owns the camera hardware exclusively. */}
      {phase === 'idle' ? (
        <CameraView ref={camRef} style={styles.preview} facing="back" mode="picture" />
      ) : (
        <View style={[styles.preview, styles.center]}>
          <Text style={styles.status}>{statusText}</Text>
        </View>
      )}

      <View style={styles.panel}>
        {backCams.length > 0 && (
          <Text style={styles.dim} numberOfLines={1}>
            {backCams.map((c) => `${c.id}${c.logical ? ' (logical)' : ''} → [${c.physicalIds.join(', ') || 'self'}]`).join('  ')}
          </Text>
        )}
        {!nativeReady && (
          <Text style={styles.warn}>
            Expo Go build: native Camera2 module unavailable — concurrent multi-camera capture
            and local merging require a development build (see README). Single capture only.
          </Text>
        )}
        <View style={styles.row}>
          {(['composite', 'panorama', 'grid'] as const).map((m) => (
            <Chip key={m} label={m} active={mergeMode === m} onPress={() => setMergeMode(m)} />
          ))}
        </View>
        <View style={styles.row}>
          <TouchableOpacity style={[styles.shutter, phase !== 'idle' && { opacity: 0.4 }]} onPress={shutter} disabled={phase !== 'idle'}>
            <View style={styles.shutterInner} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.galleryBtn} onPress={() => navigation.navigate('Gallery')}>
            <Text style={styles.dim}>Rolls</Text>
          </TouchableOpacity>
        </View>
        {statusText ? <Text style={styles.statusLine}>{statusText}</Text> : null}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  preview: { flex: 1, margin: spacing(4), borderRadius: radius.lg, overflow: 'hidden', backgroundColor: '#000' },
  panel: { padding: spacing(4), backgroundColor: colors.surface, borderTopLeftRadius: radius.lg, borderTopRightRadius: radius.lg },
  row: { flexDirection: 'row', alignItems: 'center', marginTop: spacing(3) },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing(4), padding: spacing(6) },
  dim: { color: colors.textDim, fontSize: 12 },
  warn: { color: colors.warn, fontSize: 12, marginTop: spacing(2) },
  status: { color: colors.text, fontSize: 16, fontWeight: '600' },
  statusLine: { color: colors.success, fontSize: 12, marginTop: spacing(2) },
  shutter: { width: 74, height: 74, borderRadius: 37, borderWidth: 4, borderColor: colors.accent, alignItems: 'center', justifyContent: 'center', marginRight: spacing(4) },
  shutterInner: { width: 56, height: 56, borderRadius: 28, backgroundColor: colors.accent },
  galleryBtn: { padding: spacing(3), backgroundColor: colors.surface2, borderRadius: radius.md },
});
