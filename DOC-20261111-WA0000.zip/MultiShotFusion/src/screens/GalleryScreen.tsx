
import React, { useCallback, useState } from 'react';
import { FlatList, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Screen } from '../ui/components';
import { colors, radius, spacing } from '../theme';
import { deleteRoll, listRolls, type RollEntry } from '../state/rolls';
import { useSettings } from '../state/settings';
import AdBanner from '../ads/AdBanner';

export default function GalleryScreen({ navigation }: any) {
  const [rolls, setRolls] = useState<RollEntry[]>([]);
  const { settings } = useSettings();

  useFocusEffect(useCallback(() => {
    listRolls().then(setRolls);
  }, []));

  return (
    <Screen title="Rolls">
      <FlatList
        data={rolls}
        keyExtractor={(i) => i.id}
        contentContainerStyle={{ padding: spacing(4) }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.dim}>No captures yet. Open the camera and shoot.</Text>
          </View>
        }
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card}
            onPress={() => navigation.navigate('Editor', { entry: item })}>
            {item.merged ? (
              <Image source={{ uri: item.merged }} style={styles.thumb} />
            ) : (
              <View style={[styles.thumb, styles.thumbFallback]}>
                <Text style={styles.dim}>{item.originals.length} originals</Text>
              </View>
            )}
            <View style={{ flex: 1, marginLeft: spacing(3) }}>
              <Text style={styles.cardTitle}>
                {item.mode === 'concurrent' ? 'Concurrent' : 'Sequential'} · {item.cameraIds.length || item.originals.length} cam{item.originals.length !== 1 ? 's' : ''}
              </Text>
              <Text style={styles.dim}>{new Date(item.createdAt).toLocaleString()}</Text>
            </View>
            <TouchableOpacity onPress={async () => { await deleteRoll(item); setRolls(await listRolls()); }}>
              <Text style={styles.delete}>Delete</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        )}
      />
      {/* Ads allowed here (never on capture/processing); off by default */}
      <AdBanner visible={settings.adsEnabled} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  empty: { alignItems: 'center', paddingTop: spacing(20) },
  dim: { color: colors.textDim, fontSize: 13 },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface, borderRadius: radius.md, padding: spacing(3), marginBottom: spacing(3) },
  thumb: { width: 64, height: 64, borderRadius: radius.sm, backgroundColor: '#000' },
  thumbFallback: { alignItems: 'center', justifyContent: 'center' },
  cardTitle: { color: colors.text, fontWeight: '700', marginBottom: 2 },
  delete: { color: colors.danger, fontWeight: '600', padding: spacing(2) },
});
