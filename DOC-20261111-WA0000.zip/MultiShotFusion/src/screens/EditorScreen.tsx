
import React, { useState } from 'react';
import { Image, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as ImageManipulator from 'expo-image-manipulator';
import { Screen, Chip, PrimaryButton } from '../ui/components';
import { colors, radius, spacing } from '../theme';
import * as MultiShot from '../native/MultiShot';
import type { MergeMode } from '../native/MultiShot';
import type { RollEntry } from '../state/rolls';

export default function EditorScreen({ route, navigation }: any) {
  const entry: RollEntry = route.params.entry;
  const [uri, setUri] = useState<string | null>(entry.merged ?? entry.originals[0] ?? null);
  const [busy, setBusy] = useState(false);
  const [showOriginals, setShowOriginals] = useState(false);

  const rotate = async (deg: number) => {
    if (!uri) return;
    setBusy(true);
    try {
      const ctx = ImageManipulator.manipulate(uri);
      ctx.rotate(deg);
      const r = await ctx.renderAsync();
      setUri(r.uri);
    } finally { setBusy(false); }
  };

  const flip = async () => {
    if (!uri) return;
    setBusy(true);
    try {
      const ctx = ImageManipulator.manipulate(uri);
      ctx.flip(ImageManipulator.FlipType.Horizontal);
      const r = await ctx.renderAsync();
      setUri(r.uri);
    } finally { setBusy(false); }
  };

  const restitch = async (mode: Exclude<MergeMode, 'none'>) => {
    if (!MultiShot.isNativeCaptureAvailable() || entry.originals.length < 2) return;
    setBusy(true);
    try {
      const out = await MultiShot.mergeImages(entry.originals, mode);
      setUri(out);
    } catch (e: any) {
      setUri(uri); // keep current; error surfaced via busy reset
    } finally { setBusy(false); }
  };

  return (
    <Screen title="Edit" right={<Chip label="Done" onPress={() => navigation.goBack()} />}>
      <ScrollView contentContainerStyle={{ padding: spacing(4) }}>
        {showOriginals ? (
          <ScrollView horizontal>
            {entry.originals.map((o, i) => (
              <Image key={i} source={{ uri: o }} style={[styles.img, { width: 300 }]} resizeMode="contain" />
            ))}
          </ScrollView>
        ) : (
          uri ? <Image source={{ uri }} style={styles.img} resizeMode="contain" /> : <Text style={styles.dim}>Nothing to edit.</Text>
        )}

        <Text style={styles.section}>Transform</Text>
        <View style={styles.row}>
          <Chip label="Rotate 90°" onPress={() => rotate(90)} />
          <Chip label="Flip H" onPress={flip} />
          <Chip label={showOriginals ? 'Show merged' : `Originals (${entry.originals.length})`} onPress={() => setShowOriginals(!showOriginals)} />
        </View>

        {entry.originals.length >= 2 && MultiShot.isNativeCaptureAvailable() && (
          <>
            <Text style={styles.section}>Re-merge locally</Text>
            <View style={styles.row}>
              {(['composite', 'panorama', 'grid'] as const).map((m) => (
                <Chip key={m} label={m} onPress={() => restitch(m)} />
              ))}
            </View>
          </>
        )}
        {entry.originals.length >= 2 && !MultiShot.isNativeCaptureAvailable() && (
          <Text style={styles.dim}>Re-merging requires a development build with the native module.</Text>
        )}

        <View style={{ marginTop: spacing(6) }}>
          <PrimaryButton label={busy ? 'Working…' : 'Export copy to gallery'} loading={busy}
            onPress={async () => {
              if (!uri) return;
              setBusy(true);
              try {
                const mod = await import('expo-media-library');
                const [p] = await mod.requestPermissionsAsync();
                if (p.granted) await mod.createAssetAsync(uri);
              } finally { setBusy(false); }
            }} />
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  img: { width: '100%', height: 360, borderRadius: radius.md, backgroundColor: '#000' },
  row: { flexDirection: 'row', flexWrap: 'wrap', marginTop: spacing(2) },
  section: { color: colors.text, fontWeight: '700', fontSize: 15, marginTop: spacing(5) },
  dim: { color: colors.textDim },
});
