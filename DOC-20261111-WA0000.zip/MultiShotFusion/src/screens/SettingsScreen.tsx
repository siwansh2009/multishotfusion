
import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Screen, Chip, PrimaryButton, Toggle } from '../ui/components';
import { colors, spacing } from '../theme';
import { useSettings } from '../state/settings';
import { deleteAllData } from '../state/rolls';
import * as MultiShot from '../native/MultiShot';
import type { PhysicalCameraInfo } from '../native/MultiShot';
import AdBanner from '../ads/AdBanner';

export default function SettingsScreen() {
  const { settings, update } = useSettings();
  const [cams, setCams] = useState<PhysicalCameraInfo[]>([]);

  useEffect(() => {
    if (!MultiShot.isNativeCaptureAvailable()) return;
    MultiShot.detectCameras().then(setCams).catch(() => {});
  }, []);

  return (
    <Screen title="Settings">
      <ScrollView contentContainerStyle={{ padding: spacing(5) }}>
        <Text style={styles.section}>Capture</Text>
        <Toggle label="Save original frames" value={settings.saveOriginals}
          description="Keep each camera's unmodified frame alongside the merge." onChange={(v) => update({ saveOriginals: v })} />
        <Toggle label="Import merges to gallery" value={settings.saveToGallery}
          description="Saves the merged photo to the device gallery album." onChange={(v) => update({ saveToGallery: v })} />

        <Text style={styles.section}>Default merge mode</Text>
        <View style={styles.row}>
          {(['composite', 'panorama', 'grid'] as const).map((m) => (
            <Chip key={m} label={m} active={settings.mergeMode === m} onPress={() => update({ mergeMode: m })} />
          ))}
        </View>

        <Text style={styles.section}>Quality</Text>
        <View style={styles.row}>
          {[0.8, 0.92, 1.0].map((q) => (
            <Chip key={q} label={`${Math.round(q * 100)}%`} active={settings.quality === q} onPress={() => update({ quality: q })} />
          ))}
        </View>

        <Text style={styles.section}>Advertisements</Text>
        <Toggle label="Support the app with ads" value={settings.adsEnabled}
          description="Optional. Ads appear only in the gallery/settings areas — never during capture or processing." onChange={(v) => update({ adsEnabled: v })} />

        <Text style={styles.section}>Camera hardware</Text>
        {MultiShot.isNativeCaptureAvailable() ? (
          cams.map((c) => (
            <Text key={c.id} style={styles.hw}>
              {c.facing} · id {c.id} {c.logical ? '(logical)' : ''} · physicals: [{c.physicalIds.join(', ')}] ·{' '}
              {c.supportsConcurrent ? 'concurrent capture supported' : 'sequential only'}
              {c.focalLengths.length ? ` · ${c.focalLengths.map((f) => `${f.toFixed(1)}mm`).join('/')}` : ''}
            </Text>
          ))
        ) : (
          <Text style={styles.hw}>Native module not present (Expo Go). Build a development client to enable multi-camera capture.</Text>
        )}

        <Text style={styles.section}>Privacy</Text>
        <Text style={styles.privacy}>
          MultiShot Fusion works fully offline. No account, no analytics, no uploads. Original and
          merged photos are stored only on this device. Deleting data below removes everything the app stored.
        </Text>
        <View style={{ marginTop: spacing(4) }}>
          <PrimaryButton label="Delete all app data" onPress={async () => { await deleteAllData(); }} />
        </View>
      </ScrollView>
      <AdBanner visible={settings.adsEnabled} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  section: { color: colors.text, fontWeight: '800', fontSize: 15, marginTop: spacing(6), marginBottom: spacing(1) },
  row: { flexDirection: 'row', flexWrap: 'wrap', marginTop: spacing(2) },
  hw: { color: colors.textDim, fontSize: 12, marginTop: spacing(1.5), lineHeight: 17 },
  privacy: { color: colors.textDim, fontSize: 13, lineHeight: 19 },
});
