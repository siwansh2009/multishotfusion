// Pure, dependency-free image alignment + blending engine.
// JS reference of the native Kotlin stitcher. Operates on RGBA pixels.
// @typedef {{width:number, height:number, data:Uint8ClampedArray}} Rgba

export function toGrayscale(img) {
  const { width, height, data } = img;
  const g = new Float32Array(width * height);
  for (let i = 0; i < width * height; i++) {
    g[i] = 0.299 * data[i * 4] + 0.587 * data[i * 4 + 1] + 0.114 * data[i * 4 + 2];
  }
  return g;
}

export function downsample2(g, w, h) {
  const ow = w >> 1, oh = h >> 1;
  const out = new Float32Array(ow * oh);
  for (let y = 0; y < oh; y++)
    for (let x = 0; x < ow; x++)
      out[y * ow + x] = (g[(2*y)*w + 2*x] + g[(2*y)*w + 2*x+1] + g[(2*y+1)*w + 2*x] + g[(2*y+1)*w + 2*x+1]) / 4;
  return { g: out, w: ow, h: oh };
}

function upsample2(g, w, h) {
  const out = new Float32Array(w * h * 4);
  for (let y = 0; y < h * 2; y++)
    for (let x = 0; x < w * 2; x++)
      out[y * w * 2 + x] = g[(y >> 1) * w + (x >> 1)];
  return out;
}

function ssdAt(ref, rw, rh, mov, mw, mh, dx, dy, stride) {
  const x0 = Math.max(0, dx), x1 = Math.min(rw, mw + dx);
  const y0 = Math.max(0, dy), y1 = Math.min(rh, mh + dy);
  let sum = 0, n = 0;
  for (let y = y0; y < y1; y += stride) {
    const mr = y - dy;
    for (let x = x0; x < x1; x += stride) {
      const d = ref[y * rw + x] - mov[mr * mw + (x - dx)];
      sum += d * d; n++;
      if (n > 60000) return sum / n;
    }
  }
  return n < 100 ? Number.MAX_VALUE : sum / n;
}

function searchLevel(ref, rw, rh, mov, mw, mh, range, baseDx, baseDy, stride) {
  let best = Number.MAX_VALUE, bx = baseDx, by = baseDy;
  for (let ty = baseDy - range; ty <= baseDy + range; ty++)
    for (let tx = baseDx - range; tx <= baseDx + range; tx++) {
      const s = ssdAt(ref, rw, rh, mov, mw, mh, tx, ty, stride);
      if (s < best) { best = s; bx = tx; by = ty; }
    }
  return { dx: bx, dy: by };
}

export function estimateShift(refG, rw, rh, movG, mw, mh, search) {
  let r = { g: refG, w: rw, h: rh }, m = { g: movG, w: mw, h: mh };
  let scale = 1;
  while (r.w > 96 && r.h > 96) {
    r = downsample2(r.g, r.w, r.h);
    m = downsample2(m.g, m.w, m.h);
    scale *= 2;
  }
  let dx = 0, dy = 0, step = scale;
  let range = Math.max(4, Math.round(search / scale));
  while (true) {
    // full-rate SSD + wider local search on the final (native-resolution) level
    const final = step === 1;
    const res = searchLevel(r.g, r.w, r.h, m.g, m.w, m.h, final ? 4 : range, dx, dy, final ? 1 : 2);
    dx = res.dx; dy = res.dy;
    if (final) break;
    step >>= 1;
    r = { g: upsample2(r.g, r.w, r.h), w: r.w * 2, h: r.h * 2 };
    m = { g: upsample2(m.g, m.w, m.h), w: m.w * 2, h: m.h * 2 };
    dx *= 2; dy *= 2;
    range = 3;
  }
  return { dx, dy };
}

function meanLuma(g) {
  let s = 0; for (let i = 0; i < g.length; i++) s += g[i];
  return s / g.length;
}

export function featherWeights(w, h) {
  const INF = 1e9;
  const d = new Float32Array(w * h).fill(INF);
  for (let i = 0; i < w; i++) { d[i] = 0; d[(h - 1) * w + i] = 0; }
  for (let i = 0; i < h; i++) { d[i * w] = 0; d[i * w + w - 1] = 0; }
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = y * w + x; let v = d[i];
    if (x > 0) v = Math.min(v, d[i - 1] + 1);
    if (y > 0) v = Math.min(v, d[i - w] + 1);
    d[i] = v;
  }
  for (let y = h - 1; y >= 0; y--) for (let x = w - 1; x >= 0; x--) {
    const i = y * w + x; let v = d[i];
    if (x < w - 1) v = Math.min(v, d[i + 1] + 1);
    if (y < h - 1) v = Math.min(v, d[i + w] + 1);
    d[i] = v;
  }
  let maxD = 0; for (let i = 0; i < d.length; i++) maxD = Math.max(maxD, d[i]);
  const out = new Float32Array(w * h);
  for (let i = 0; i < d.length; i++) out[i] = maxD > 0 ? Math.min(1, d[i] / maxD) : 1;
  return out;
}

export function featherBlend(base, mov, dx, dy, matchExposure) {
  if (matchExposure === undefined) matchExposure = true;
  const refMean = meanLuma(toGrayscale(base));
  const scale = matchExposure
    ? Math.min(2, Math.max(0.5, refMean / Math.max(1, meanLuma(toGrayscale(mov)))))
    : 1;
  const minX = Math.min(0, dx), minY = Math.min(0, dy);
  const w = Math.max(base.width, dx + mov.width) - minX;
  const h = Math.max(base.height, dy + mov.height) - minY;
  const out = new Uint8ClampedArray(w * h * 4);
  const wB = featherWeights(base.width, base.height);
  const wM = featherWeights(mov.width, mov.height);
  for (let y = 0; y < h; y++) {
    const by = y + minY, my = by - dy;
    for (let x = 0; x < w; x++) {
      const bx = x + minX, mx = bx - dx;
      const ib = by >= 0 && by < base.height && bx >= 0 && bx < base.width;
      const im = my >= 0 && my < mov.height && mx >= 0 && mx < mov.width;
      const oi = (y * w + x) * 4;
      if (ib && im) {
        const bi = (by * base.width + bx) * 4, mi = (my * mov.width + mx) * 4;
        const sb = wB[by * base.width + bx] ** 2, sm = wM[my * mov.width + mx] ** 2;
        const tot = sb + sm;
        for (let c = 0; c < 3; c++)
          out[oi + c] = tot > 1e-6
            ? (base.data[bi + c] * sb + mov.data[mi + c] * scale * sm) / tot
            : base.data[bi + c];
        out[oi + 3] = 255;
      } else if (ib) {
        const bi = (by * base.width + bx) * 4;
        out.set(base.data.subarray(bi, bi + 4), oi);
      } else if (im) {
        const mi = (my * mov.width + mx) * 4;
        for (let c = 0; c < 3; c++) out[oi + c] = mov.data[mi + c] * scale;
        out[oi + 3] = 255;
      }
    }
  }
  return { width: w, height: h, data: out };
}

export function stitchRow(images) {
  if (images.length === 0) throw new Error('stitchRow: no images');
  let acc = images[0];
  for (let i = 1; i < images.length; i++) {
    const accG = toGrayscale(acc);
    const movG = toGrayscale(images[i]);
    const search = Math.floor(Math.max(acc.width, images[i].width) / 3);
    const { dx, dy } = estimateShift(accG, acc.width, acc.height, movG, images[i].width, images[i].height, search);
    acc = featherBlend(acc, images[i], dx, dy, true);
  }
  return acc;
}

export function compositeMerge(images) {
  if (images.length === 0) throw new Error('compositeMerge: no images');
  let acc = images[0];
  const refG = toGrayscale(acc);
  for (let i = 1; i < images.length; i++) {
    const movG = toGrayscale(images[i]);
    const search = Math.floor(acc.width / 6);
    const { dx, dy } = estimateShift(refG, acc.width, acc.height, movG, images[i].width, images[i].height, search);
    acc = featherBlend(acc, images[i], dx, dy, true);
  }
  return acc;
}

export function sideBySide(images) {
  const cols = Math.ceil(Math.sqrt(images.length));
  const rows = Math.ceil(images.length / cols);
  const cellW = Math.floor(images[0].width / 2);
  const cellH = Math.floor(images[0].height / 2);
  const w = cols * cellW, h = rows * cellH;
  const out = new Uint8ClampedArray(w * h * 4);
  images.forEach((img, i) => {
    const ox = (i % cols) * cellW, oy = Math.floor(i / cols) * cellH;
    for (let y = 0; y < cellH; y++) for (let x = 0; x < cellW; x++) {
      const sx = Math.floor(x * img.width / cellW), sy = Math.floor(y * img.height / cellH);
      const si = (sy * img.width + sx) * 4, di = ((oy + y) * w + ox + x) * 4;
      out.set(img.data.subarray(si, si + 4), di);
    }
  });
  return { width: w, height: h, data: out };
}
