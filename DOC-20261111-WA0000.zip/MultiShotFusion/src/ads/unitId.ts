
// Put a real AdMob banner unit id in app.json -> expo.extra.admob.bannerUnitId.
// Left empty by default: the app ships 100% ad-free unless the user opts in AND
// a unit id is configured at build time.
export function getAdUnitId(): string {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const Constants = require('expo-constants').default;
    const cfg = Constants.expoConfig?.extra?.admob ?? {};
    return cfg.enabled && cfg.bannerUnitId ? cfg.bannerUnitId : '';
  } catch {
    return '';
  }
}
