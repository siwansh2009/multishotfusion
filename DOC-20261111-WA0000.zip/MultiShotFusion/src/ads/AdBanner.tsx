
import React, { useEffect, useState } from 'react';
import { Platform, View } from 'react-native';

// Ads are strictly optional, off by default, and never rendered on the
// capture or processing screens. Nothing loads until enabled in settings.
export default function AdBanner({ visible }: { visible: boolean }) {
  const [Banner, setBanner] = useState<any>(null);
  useEffect(() => {
    let mounted = true;
    (async () => {
      if (!visible || __DEV__ || Platform.OS !== 'android') return;
      try {
        const mod = require('react-native-google-mobile-ads');
        const { getAdUnitId } = require('../ads/unitId');
        const unitId = getAdUnitId();
        if (!unitId) return;
        await mod.default().initialize();
        if (mounted) setBanner(() => mod.BannerAd);
        globalThis.__msfAdUnitId = unitId;
      } catch { /* ads unavailable — core app is unaffected */ }
    })();
    return () => { mounted = false; };
  }, [visible]);
  if (!visible || __DEV__ || !Banner) return null;
  return (
    <View style={{ alignItems: 'center' }}>
      <Banner unitId={globalThis.__msfAdUnitId} size={'ANCHORED_ADAPTIVE_BANNER'} />
    </View>
  );
}
