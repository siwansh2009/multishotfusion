
export const colors = {
  bg: '#0B0D10',
  surface: '#14171C',
  surface2: '#1C2129',
  border: '#262C36',
  text: '#F2F5F9',
  textDim: '#8B95A3',
  accent: '#4F8CFF',
  accent2: '#7C5CFF',
  success: '#34D399',
  warn: '#FBBF24',
  danger: '#F87171',
};
export const spacing = (n: number) => n * 4;
export const radius = { sm: 8, md: 14, lg: 22, pill: 999 };
