
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useState } from 'react';
import type { MergeMode } from '../native/MultiShot';

export interface Settings {
  mergeMode: Exclude<MergeMode, 'none'>;
  quality: number;              // 0..1 JPEG quality
  saveOriginals: boolean;
  saveToGallery: boolean;       // import merged photos into device gallery
  adsEnabled: boolean;          // optional ads; NEVER shown on camera/processing screens
}

const KEY = 'msf.settings.v1';
export const defaultSettings: Settings = {
  mergeMode: 'composite',
  quality: 0.92,
  saveOriginals: true,
  saveToGallery: true,
  adsEnabled: false,
};

export async function loadSettings(): Promise<Settings> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (!raw) return defaultSettings;
    return { ...defaultSettings, ...JSON.parse(raw) };
  } catch {
    return defaultSettings;
  }
}

export async function saveSettings(s: Settings): Promise<void> {
  await AsyncStorage.setItem(KEY, JSON.stringify(s));
}

export function useSettings() {
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    loadSettings().then((s) => { setSettings(s); setLoaded(true); });
  }, []);
  const update = async (patch: Partial<Settings>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    await saveSettings(next);
  };
  return { settings, loaded, update };
}
