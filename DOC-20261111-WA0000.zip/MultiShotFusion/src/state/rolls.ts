
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import type { CaptureResult } from '../native/MultiShot';

export interface RollEntry {
  id: string;
  createdAt: number;
  mode: 'concurrent' | 'sequential';
  cameraIds: string[];
  originals: string[];
  merged: string | null;
  importedAssetId?: string;
}

const INDEX_KEY = 'msf.rolls.v1';

async function readIndex(): Promise<RollEntry[]> {
  try {
    const raw = await AsyncStorage.getItem(INDEX_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

async function writeIndex(entries: RollEntry[]) {
  await AsyncStorage.setItem(INDEX_KEY, JSON.stringify(entries.slice(0, 100)));
}

/** Persist a capture locally; optionally import the merged photo into the gallery. */
export async function recordCapture(result: CaptureResult, opts: { saveOriginals: boolean; saveToGallery: boolean }): Promise<RollEntry> {
  let originals = result.originals;
  if (!opts.saveOriginals) {
    originals = []; // originals stay on disk (privacy: fully local); just not indexed
  }
  let imported: string | undefined;
  if (opts.saveToGallery && result.merged) {
    try {
      const [perm] = await MediaLibrary.requestPermissionsAsync();
      if (perm.granted) {
        const asset = await MediaLibrary.createAssetAsync(result.merged);
        imported = asset.id;
      }
    } catch { /* gallery import is best-effort */ }
  }
  const entry: RollEntry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: Date.now(),
    mode: result.mode,
    cameraIds: result.cameraIds,
    originals,
    merged: result.merged,
    importedAssetId: imported,
  };
  const all = await readIndex();
  await writeIndex([entry, ...all]);
  return entry;
}

export async function listRolls(): Promise<RollEntry[]> {
  return readIndex();
}

export async function deleteRoll(entry: RollEntry): Promise<void> {
  const files = [...entry.originals, ...(entry.merged ? [entry.merged] : [])];
  for (const f of files) {
    try { await FileSystem.deleteAsync(f, { idempotent: true }); } catch { /* ignore */ }
  }
  if (entry.importedAssetId) {
    try {
      const asset = await MediaLibrary.getAssetInfoAsync(entry.importedAssetId);
      if (asset.localUri || asset.uri) await MediaLibrary.deleteAssetsAsync([entry.importedAssetId]);
    } catch { /* ignore */ }
  }
  const all = await readIndex();
  await writeIndex(all.filter((e) => e.id !== entry.id));
}

export async function deleteAllData(): Promise<void> {
  const all = await readIndex();
  for (const e of all) {
    const files = [...e.originals, ...(e.merged ? [e.merged] : [])];
    for (const f of files) {
      try { await FileSystem.deleteAsync(f, { idempotent: true }); } catch { /* ignore */ }
    }
  }
  await AsyncStorage.multiRemove([INDEX_KEY]);
}
