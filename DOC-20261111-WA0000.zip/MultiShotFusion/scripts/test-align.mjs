
// Unit tests for the imageAlign reference engine (mirrors the Kotlin stitcher).
// Run: node scripts/test-align.mjs
import { strict as assert } from 'node:assert';
import {
  toGrayscale, estimateShift, featherBlend, featherWeights,
  stitchRow, compositeMerge, sideBySide,
} from '../src/utils/imageAlign.js';

function makeImage(w, h, fn) {
  const data = new Uint8ClampedArray(w * h * 4);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const [r, g, b] = fn(x, y);
    const i = (y * w + x) * 4;
    data[i] = r; data[i + 1] = g; data[i + 2] = b; data[i + 3] = 255;
  }
  return { width: w, height: h, data };
}

// structured texture: gradient + checker + marker blocks (SSD needs real structure)
function texture(x, y) {
  const base = (x * 2 + y * 3) % 256;
  const chk = ((x >> 4) + (y >> 4)) % 2 ? 40 : 0;
  let r = (base + chk) % 256, g = (base * 2 + chk) % 256, b = (base * 3 + chk) % 256;
  if (x > 120 && x < 150 && y > 60 && y < 90) { r = 255; g = 40; b = 40; }   // marker A
  if (x > 30 && x < 55 && y > 20 && y < 45) { r = 40; g = 255; b = 60; }      // marker B
  return [r, g, b];
}

function shiftImage(img, dx, dy) {
  const out = new Uint8ClampedArray(img.width * img.height * 4);
  for (let y = 0; y < img.height; y++) for (let x = 0; x < img.width; x++) {
    const sx = x - dx, sy = y - dy;
    if (sx >= 0 && sx < img.width && sy >= 0 && sy < img.height)
      out.set(img.data.subarray((sy * img.width + sx) * 4, (sy * img.width + sx) * 4 + 4), (y * img.width + x) * 4);
  }
  return { width: img.width, height: img.height, data: out };
}

let passed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log(`ok - ${name}`); }
  catch (e) { console.error(`FAIL - ${name}\n  ${e.message}`); process.exitCode = 1; }
}

const W = 200, H = 150;
const base = makeImage(W, H, texture);

test('estimateShift recovers a known (25,-10) content translation', () => {
  const mov = shiftImage(base, 25, -10);
  const g1 = toGrayscale(base), g2 = toGrayscale(mov);
  const { dx, dy } = estimateShift(g1, W, H, g2, W, H, 60);
  // convention: returned shift is the placement offset for mov onto the ref canvas
  // (s = -t where t is the content motion); featherBlend consumes it directly.
  assert.ok(Math.abs(dx + 25) <= 1 && Math.abs(dy - 10) <= 1, `got (${dx},${dy}), expected ~(-25,10) placement`);
});

test('estimateShift recovers a negative (-40,15) content translation', () => {
  const mov = shiftImage(base, -40, 15);
  const g1 = toGrayscale(base), g2 = toGrayscale(mov);
  const { dx, dy } = estimateShift(g1, W, H, g2, W, H, 60);
  assert.ok(Math.abs(dx - 40) <= 1 && Math.abs(dy + 15) <= 1, `got (${dx},${dy}), expected ~(40,-15) placement`);
});

test('featherBlend canvas grows to the union of shifted frames', () => {
  const mov = shiftImage(base, 30, 0);
  const out = featherBlend(base, mov, 30, 0, false);
  assert.equal(out.width, W + 30);
  assert.equal(out.height, H);
});

test('featherWeights: zero at borders, one at center', () => {
  const w = featherWeights(40, 40);
  assert.equal(w[0], 0);                    // corner
  assert.equal(w[20 * 40 + 20], 1);         // exact center
});

test('stitchRow of two overlapping frames widens the canvas by the shift', () => {
  const mov = shiftImage(base, 35, 5);
  const out = stitchRow([base, mov]);
  assert.ok(Math.abs(out.width - (W + 35)) <= 2, `width ${out.width}, expected ~${W + 35}`);
  assert.ok(out.height >= H);
});

test('compositeMerge matches exposure of a darker frame', () => {
  const dark = makeImage(W, H, (x, y) => texture(x, y).map((v) => v * 0.4));
  const out = compositeMerge([base, dark]);
  // union canvas may grow by a pixel from the placement shift; content stays registered
  assert.ok(out.width >= W && out.width <= W + 2, `width ${out.width}`);
  assert.ok(out.height >= H && out.height <= H + 2, `height ${out.height}`);
  // blended result must be brighter than the dark frame's average contribution
  let sum = 0, n = 0;
  for (let i = 0; i < out.data.length; i += 4) { sum += 0.299 * out.data[i] + 0.587 * out.data[i + 1] + 0.114 * out.data[i + 2]; n++; }
  const darkMean = 0;
  assert.ok(sum / n > 60, `mean luma ${(sum / n).toFixed(1)} too low — exposure match failed`);
});

test('sideBySide lays out 4 images in a 2x2 grid', () => {
  const imgs = [base, base, base, base];
  const out = sideBySide(imgs);
  assert.equal(out.width, 2 * Math.floor(W / 2));
  assert.equal(out.height, 2 * Math.floor(H / 2));
});

test('pyramid handles a large frame (512x384) efficiently', () => {
  const big = makeImage(512, 384, texture);
  const mov = shiftImage(big, 60, -25);
  const t0 = Date.now();
  const g1 = toGrayscale(big), g2 = toGrayscale(mov);
  const { dx, dy } = estimateShift(g1, 512, 384, g2, 512, 384, 100);
  const ms = Date.now() - t0;
  assert.ok(Math.abs(dx + 60) <= 2 && Math.abs(dy - 25) <= 2, `got (${dx},${dy}), expected ~(-60,25) placement`);
  assert.ok(ms < 5000, `took ${ms}ms`);
  console.log(`  (512x384 alignment in ${ms}ms)`);
});

console.log(`\n${passed} tests passed${process.exitCode ? ' (with failures)' : ''}`);
