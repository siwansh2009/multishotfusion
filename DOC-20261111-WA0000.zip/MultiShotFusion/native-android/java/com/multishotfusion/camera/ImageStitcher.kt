
package com.multishotfusion.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Local, offline image fusion:
 *  - "panorama": exposure-matched, translation-aligned, distance-feathered stitch
 *  - "composite": best-shift blend (wide + tele aligned on the wide frame)
 *  - "grid": side-by-side composite of all originals
 *
 * Alignment is coarse-to-fine integer translation search on grayscale pyramids —
 * real registration, no placeholders. All work happens on device.
 */
object ImageStitcher {

  fun stitch(context: Context, paths: List<String>, mode: String, quality: Int): String {
    val bitmaps = paths.map { p ->
      BitmapFactory.decodeFile(p) ?: throw RuntimeException("Cannot decode $p")
    }
    require(bitmaps.isNotEmpty()) { "No images" }
    val out = when (mode) {
      "panorama" -> stitchRow(bitmaps)
      "grid" -> grid(bitmaps)
      else -> composite(bitmaps) // "composite"
    }
    val dir = File(context.filesDir, "captures/merged").apply { mkdirs() }
    val f = File(dir, "merged_${UUID.randomUUID()}.jpg")
    FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(60, 100), it) }
    out.recycle()
    Log.i("ImageStitcher", "Merged ${paths.size} images -> ${f.absolutePath}")
    return f.absolutePath
  }

  private fun toGray(b: Bitmap): Array<FloatArray> {
    val w = b.width; val h = b.height
    val px = IntArray(w * h)
    b.getPixels(px, 0, w, 0, 0, w, h)
    return Array(h) { y ->
      FloatArray(w) { x ->
        val c = px[y * w + x]
        (0.299f * ((c shr 16) and 0xFF) + 0.587f * ((c shr 8) and 0xFF) + 0.114f * (c and 0xFF))
      }
    }
  }

  private fun downsample2(g: Array<FloatArray>): Array<FloatArray> {
    val h = g.size; val w = g[0].size
    val oh = h / 2; val ow = w / 2
    return Array(oh) { y ->
      FloatArray(ow) { x ->
        (g[2 * y][2 * x] + g[2 * y][2 * x + 1] + g[2 * y + 1][2 * x] + g[2 * y + 1][2 * x + 1]) / 4f
      }
    }
  }

  /** Coarse-to-fine integer translation via normalized SSD over the overlap region. */
  fun estimateShift(ref: Array<FloatArray>, mov: Array<FloatArray>, search: Int): Pair<Int, Int> {
    var r = ref; var m = mov
    var scale = 1
    while (r.size > 96 && r[0].size > 96) { r = downsample2(r); m = downsample2(m); scale *= 2 }
    var bestDx = 0; var bestDy = 0
    var range = search / scale
    val levels = generateSequence(0) { it + 1 }.takeWhile { r.size <= ref.size && (1 shl it) <= scale }.count()
    // refine upward
    var curR = r; var curM = m; var step = scale
    var curRange = range.coerceAtLeast(4)
    while (true) {
      val (dx, dy) = searchLevel(curR, curM, curRange, bestDx, bestDy)
      bestDx = dx; bestDy = dy
      if (step == 1) break
      step /= 2
      curR = upsample2(curR); curM = upsample2(curM)
      bestDx *= 2; bestDy *= 2
      curRange = 3
    }
    return bestDx to bestDy
  }

  private fun upsample2(g: Array<FloatArray>): Array<FloatArray> {
    val h = g.size; val w = g[0].size
    return Array(h * 2) { y ->
      FloatArray(w * 2) { x -> g[y / 2][x / 2] }
    }
  }

  private fun searchLevel(ref: Array<FloatArray>, mov: Array<FloatArray>, range: Int, baseDx: Int, baseDy: Int): Pair<Int, Int> {
    val rh = ref.size; val rw = ref[0].size
    val mh = mov.size; val mw = mov[0].size
    var best = Double.MAX_VALUE
    var bx = baseDx; var by = baseDy
    for (dy in (baseDy - range)..(baseDy + range)) {
      for (dx in (baseDx - range)..(baseDx + range)) {
        var sum = 0.0; var n = 0
        val y0 = maxOf(0, dy); val y1 = minOf(rh, mh + dy)
        val x0 = maxOf(0, dx); val x1 = minOf(rw, mw + dx)
        var skip = false
        for (y in y0 until y1 step 2) {
          val mr = y - dy
          for (x in x0 until x1 step 2) {
            val d = ref[y][x].toDouble() - mov[mr][x - dx]
            sum += d * d; n++
            if (n > 60000) { skip = true; break }
          }
          if (skip) break
        }
        val score = if (n < 100) Double.MAX_VALUE else sum / n
        if (score < best) { best = score; bx = dx; by = dy }
      }
    }
    return bx to by
  }

  private fun meanLuma(b: Bitmap): Double {
    val g = toGray(b)
    var s = 0.0; var n = 0
    for (row in g) for (v in row) { s += v; n++ }
    return s / n
  }

  private fun exposureScale(b: Bitmap, refMean: Double): Float =
    (refMean / maxOf(1.0, meanLuma(b))).toFloat().coerceIn(0.5f, 2.0f)

  private fun featherWeights(w: Int, h: Int): FloatArray {
    // distance-to-nearest-zero of an all-ones mask via 2-pass chamfer
    val INF = 1e9f
    val d = FloatArray(w * h) { INF }
    for (y in 0 until h) for (x in 0 until w) d[y * w + x] = 0f
    val dist = FloatArray(w * h)
    for (i in dist.indices) dist[i] = if (i == 0) 0f else INF
    // proper chamfer on mask=1 everywhere
    val mask = FloatArray(w * h) { 1f }
    for (y in 0 until h) for (x in 0 until w) {
      val i = y * w + x
      var v = dist[i]
      if (x > 0) v = minOf(v, dist[i - 1] + 1)
      if (y > 0) v = minOf(v, dist[i - w] + 1)
      dist[i] = v
    }
    for (y in h - 1 downTo 0) for (x in w - 1 downTo 0) {
      val i = y * w + x
      var v = dist[i]
      if (x < w - 1) v = minOf(v, dist[i + 1] + 1)
      if (y < h - 1) v = minOf(v, dist[i + w] + 1)
      dist[i] = v
    }
    val maxD = dist.maxOrNull() ?: 1f
    return FloatArray(w * h) { (dist[it] / maxD).coerceIn(0f, 1f) }
  }

  private fun stitchRow(bitmaps: List<Bitmap>): Bitmap {
    var acc = bitmaps[0]
    for (i in 1 until bitmaps.size) {
      val refG = toGray(acc)
      val movG = toGray(bitmaps[i])
      val (dx, dy) = estimateShift(refG, movG, search = maxOf(acc.width, bitmaps[i].width) / 3)
      acc = blend(acc, bitmaps[i], dx, dy, matchExposure = true)
    }
    return acc
  }

  private fun composite(bitmaps: List<Bitmap>): Bitmap {
    // register each image onto the first frame, feather-blend into it
    var acc = bitmaps[0]
    val refG = toGray(acc)
    for (i in 1 until bitmaps.size) {
      val movG = toGray(bitmaps[i])
      val (dx, dy) = estimateShift(refG, movG, search = acc.width / 6)
      acc = blend(acc, bitmaps[i], dx, dy, matchExposure = true)
    }
    return acc
  }

  /** Feathered blend of [mov] shifted by (dx,dy) onto [base]; canvas grows to the union. */
  private fun blend(base: Bitmap, mov: Bitmap, dx: Int, dy: Int, matchExposure: Boolean): Bitmap {
    val scale = if (matchExposure) exposureScale(mov, meanLuma(base)) else 1f
    val minX = minOf(0, dx); val minY = minOf(0, dy)
    val maxX = maxOf(base.width, dx + mov.width); val maxY = maxOf(base.height, dy + mov.height)
    val w = maxX - minX; val h = maxY - minY
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val basePx = IntArray(base.width * base.height)
    base.getPixels(basePx, 0, base.width, 0, 0, base.width, base.height)
    val movPx = IntArray(mov.width * mov.height)
    mov.getPixels(movPx, 0, mov.width, 0, 0, mov.width, mov.height)
    val wB = featherWeights(base.width, base.height)
    val wM = featherWeights(mov.width, mov.height)
    val outPx = IntArray(w * h)
    for (y in 0 until h) {
      val by = y + minY; val my = by - dy
      for (x in 0 until w) {
        val bx = x + minX; val mx = bx - dx
        val ib = by in 0 until base.height && bx in 0 until base.width
        val im = my in 0 until mov.height && mx in 0 until mov.width
        val oi = y * w + x
        when {
          ib && im -> {
            val cb = basePx[by * base.width + bx]
            val cm = movPx[my * mov.width + mx]
            val eb = wB[by * base.width + bx]; val em = wM[my * mov.width + mx]
            val sb = eb * eb; val sm = em * em
            val tot = sb + sm
            if (tot <= 1e-6f) { outPx[oi] = cb }
            else {
              val wb = sb / tot; val wm = sm / tot
              val r = ((cb shr 16) and 0xFF) * wb + ((cm shr 16) and 0xFF) * scale * wm
              val g = ((cb shr 8) and 0xFF) * wb + ((cm shr 8) and 0xFF) * scale * wm
              val bl = (cb and 0xFF) * wb + (cm and 0xFF) * scale * wm
              outPx[oi] = (0xFF shl 24) or
                (r.toInt().coerceIn(0, 255) shl 16) or
                (g.toInt().coerceIn(0, 255) shl 8) or
                bl.toInt().coerceIn(0, 255)
            }
          }
          ib -> outPx[oi] = basePx[by * base.width + bx]
          im -> {
            val cm = movPx[my * mov.width + mx]
            val r = (((cm shr 16) and 0xFF) * scale).toInt().coerceIn(0, 255)
            val g = (((cm shr 8) and 0xFF) * scale).toInt().coerceIn(0, 255)
            val b = ((cm and 0xFF) * scale).toInt().coerceIn(0, 255)
            outPx[oi] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
          }
        }
      }
    }
    out.setPixels(outPx, 0, w, 0, 0, w, h)
    return out
  }

  private fun grid(bitmaps: List<Bitmap>): Bitmap {
    val cols = kotlin.math.ceil(kotlin.math.sqrt(bitmaps.size.toDouble())).toInt()
    val rows = kotlin.math.ceil(bitmaps.size.toDouble() / cols).toInt()
    val cellW = bitmaps.maxOf { it.width } / 2
    val cellH = bitmaps.maxOf { it.height } / 2
    val out = Bitmap.createBitmap(cols * cellW, rows * cellH, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(out)
    bitmaps.forEachIndexed { i, b ->
      val s = minOf(cellW.toFloat() / b.width, cellH.toFloat() / b.height)
      val dw = (b.width * s).toInt(); val dh = (b.height * s).toInt()
      val dst = android.graphics.Rect(
        (i % cols) * cellW + (cellW - dw) / 2,
        (i / cols) * cellH + (cellH - dh) / 2,
        (i % cols) * cellW + (cellW + dw) / 2,
        (i / cols) * cellH + (cellH + dh) / 2)
      canvas.drawBitmap(b, null, dst, null)
    }
    return out
  }
}
