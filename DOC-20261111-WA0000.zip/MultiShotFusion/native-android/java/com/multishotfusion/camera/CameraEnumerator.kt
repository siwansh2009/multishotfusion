
package com.multishotfusion.camera

import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build

data class CameraInfoNative(
  val id: String,
  val facing: String,
  val logical: Boolean,
  val physicalIds: List<String>,
  val focalLengths: List<Float>,
) {
  val supportsConcurrent: Boolean
    get() = logical && physicalIds.size >= 2
}

/** Enumerates logical cameras and their underlying physical cameras (Camera2, API 28+). */
class CameraEnumerator(private val manager: CameraManager) {

  private fun all(): List<CameraInfoNative> =
    manager.cameraIdList.map { id ->
      val ch = manager.getCameraCharacteristics(id)
      val caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
      val logical = Build.VERSION.SDK_INT >= 28 &&
        caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)
      val physical = if (Build.VERSION.SDK_INT >= 28) ch.physicalCameraIds.toList() else emptyList()
      val facing = when (ch.get(CameraCharacteristics.LENS_FACING)) {
        CameraCharacteristics.LENS_FACING_FRONT -> "front"
        CameraCharacteristics.LENS_FACING_BACK -> "back"
        else -> "external"
      }
      val foci = (ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
        ?: floatArrayOf()).toList()
      CameraInfoNative(id, facing, logical, physical, foci)
    }

  fun logicalCameras(): List<CameraInfoNative> = all()

  fun maxJpegSize(logicalId: String): android.util.Size {
    val ch = manager.getCameraCharacteristics(logicalId)
    val streamMap = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
    val jpegSizes = streamMap.getOutputSizes(android.graphics.ImageFormat.JPEG)
    return jpegSizes?.maxByOrNull { it.width * it.height } ?: android.util.Size(1920, 1080)
  }

  fun sensorOrientation(logicalId: String): Int =
    manager.getCameraCharacteristics(logicalId)
      .get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
}
