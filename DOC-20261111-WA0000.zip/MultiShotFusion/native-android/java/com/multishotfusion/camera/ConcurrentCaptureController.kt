
package com.multishotfusion.camera

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * TRUE simultaneous capture from multiple physical cameras.
 *
 * Opens the logical camera once, creates one session whose outputs are each
 * bound to a physical camera id (OutputConfiguration.setPhysicalCameraId), then
 * issues ONE still-capture request with all surfaces as targets. Every physical
 * camera is exposed at the same moment by the HAL. If the HAL/OEM refuses the
 * configuration this throws and the caller falls back to sequential capture.
 */
class ConcurrentCaptureController(
  private val context: Context,
  private val manager: CameraManager,
  private val logical: CameraInfoNative,
  private val physicalIds: List<String>,
) {
  private val thread = HandlerThread("msf-concurrent").apply { start() }
  private val handler = Handler(thread.looper)

  fun capture(): Map<String, ByteArray> {
    if (Build.VERSION.SDK_INT < 28) throw RuntimeException("Multi-camera requires API 28+")
    val size = CameraEnumerator(manager).maxJpegSize(logical.id)
    val readers = physicalIds.map { id ->
      ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 2).also { r ->
        // Tag the reader with its physical camera id
        r.setOnImageAvailableListener({ }, handler)
      }
    }
    val done = CountDownLatch(physicalIds.size)
    val results = mutableMapOf<String, ByteArray>()
    val errors = mutableListOf<Throwable>()

    physicalIds.forEachIndexed { idx, id ->
      readers[idx].setOnImageAvailableListener({ reader ->
        try {
          reader.acquireLatestImage()?.use { img ->
            val buf = img.planes[0].buffer
            val bytes = ByteArray(buf.remaining())
            buf.get(bytes)
            synchronized(results) { results[id] = bytes }
          }
        } catch (t: Throwable) {
          synchronized(errors) { errors.add(t) }
        } finally {
          done.countDown()
        }
      }, handler)
    }

    val openLatch = CountDownLatch(1)
    var device: CameraDevice? = null
    var openError: Throwable? = null
    manager.openCamera(logical.id, handler, object : CameraDevice.StateCallback() {
      override fun onOpened(d: CameraDevice) { device = d; openLatch.countDown() }
      override fun onDisconnected(d: CameraDevice) { d.close(); openError = RuntimeException("Camera disconnected"); openLatch.countDown() }
      override fun onError(d: CameraDevice, error: Int) { d.close(); openError = RuntimeException("Camera error $error"); openLatch.countDown() }
    })
    if (!openLatch.await(5, TimeUnit.SECONDS) || device == null) {
      cleanup(readers, thread)
      throw openError ?: RuntimeException("Timeout opening camera")
    }

    val configured = CountDownLatch(1)
    var session: CameraCaptureSession? = null
    var configError: Throwable? = null
    val outputs = readers.mapIndexed { idx, r ->
      OutputConfiguration(r.surface).apply { setPhysicalCameraId(physicalIds[idx]) }
    }
    val sc = SessionConfiguration(
      SessionConfiguration.SESSION_REGULAR,
      outputs,
      { it.run() }, // executor
      object : CameraCaptureSession.StateCallback() {
        override fun onConfigured(s: CameraCaptureSession) { session = s; configured.countDown() }
        override fun onConfigureFailed(s: CameraCaptureSession) {
          configError = RuntimeException("Session configuration failed (HAL rejected concurrent physical streams)")
          configured.countDown()
        }
      }
    )
    device!!.createCaptureSession(sc)
    if (!configured.await(5, TimeUnit.SECONDS) || session == null) {
      device!!.close(); cleanup(readers, thread)
      throw configError ?: RuntimeException("Timeout configuring session")
    }

    val captured = CountDownLatch(1)
    var captureFailed = false
    val request = device!!.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
      readers.forEach { addTarget(it.surface) }
      set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
      set(CaptureRequest.JPEG_ORIENTATION, CameraEnumerator(manager).sensorOrientation(logical.id))
    }.build()
    session!!.capture(request, object : CameraCaptureSession.CaptureCallback() {
      override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: android.hardware.camera2.TotalCaptureResult) {
        captured.countDown()
      }
      override fun onCaptureFailed(session: CameraCaptureSession, request: CaptureRequest, failure: android.hardware.camera2.CaptureFailure) {
        captureFailed = true; captured.countDown()
      }
    }, handler)
    if (!captured.await(8, TimeUnit.SECONDS)) captureFailed = true
    done.await(8, TimeUnit.SECONDS)

    try { session?.close() } catch (_: Throwable) {}
    try { device?.close() } catch (_: Throwable) {}
    cleanup(readers, thread)

    if (captureFailed) throw RuntimeException("Capture failed")
    synchronized(errors) { if (errors.isNotEmpty()) throw RuntimeException("Frame error: ${errors.first().message}") }
    if (results.size != physicalIds.size) throw RuntimeException("Incomplete concurrent capture (${results.size}/${physicalIds.size})")
    return results
  }

  private fun cleanup(readers: List<ImageReader>, thread: HandlerThread) {
    readers.forEach { try { it.close() } catch (_: Throwable) {} }
    thread.quitSafely()
  }
}
