
package com.multishotfusion.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.util.Log
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableArray
import com.facebook.react.bridge.ReadableMap
import java.io.File
import java.util.UUID

/**
 * MultiShotFusion — native Camera2 bridge.
 *
 * Provides:
 *  - detectCameras(): enumerate logical + physical cameras and concurrent capability
 *  - capture(options): concurrent multi-physical-camera still capture when the
 *    hardware/Camera HAL supports it (never faked), sequential fallback otherwise
 *  - mergeImages(paths, mode): local alignment + stitching + composite merging
 *
 * Everything runs offline. No image ever leaves the device.
 */
class MultiShotFusionModule(private val reactContext: ReactApplicationContext) :
  ReactContextBaseJavaModule(reactContext) {

  override fun getName(): String = "MultiShotFusionModule"

  private fun hasCameraPermission(): Boolean =
    reactContext.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

  @ReactMethod
  fun detectCameras(promise: Promise) {
    try {
      if (!hasCameraPermission()) {
        promise.reject("ERR_PERMISSION", "Camera permission not granted")
        return
      }
      val manager = reactContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
      val result = Arguments.createArray()
      for (id in manager.cameraIdList) {
        val ch = manager.getCameraCharacteristics(id)
        val caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
        val isLogical = Build.VERSION.SDK_INT >= 28 &&
          caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)
        val physicalIds = if (Build.VERSION.SDK_INT >= 28) {
          ch.physicalCameraIds.toList()
        } else emptyList()
        val facing = when (ch.get(CameraCharacteristics.LENS_FACING)) {
          CameraCharacteristics.LENS_FACING_FRONT -> "front"
          CameraCharacteristics.LENS_FACING_BACK -> "back"
          else -> "external"
        }
        val foci = (ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
          ?: floatArrayOf()).map { it.toDouble() }
        val map = Arguments.createMap().apply {
          putString("id", id)
          putString("facing", facing)
          putBoolean("logical", isLogical)
          putBoolean("supportsConcurrent", isLogical && physicalIds.size >= 2)
          putArray("physicalIds", Arguments.fromList(physicalIds))
          putArray("focalLengths", Arguments.fromList(foci))
        }
        result.pushMap(map)
      }
      promise.resolve(result)
    } catch (t: Throwable) {
      Log.e(NAME, "detectCameras failed", t)
      promise.reject("ERR_DETECTION", t.message, t)
    }
  }

  @ReactMethod
  fun capture(options: ReadableMap, promise: Promise) {
    val mergeMode = options.getString("mergeMode") ?: "composite"
    val quality = if (options.hasKey("quality")) (options.getDouble("quality") * 100).toInt() else 92
    Thread {
      try {
        if (!hasCameraPermission()) {
          promise.reject("ERR_PERMISSION", "Camera permission not granted")
          return@Thread
        }
        val manager = reactContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val enumerator = CameraEnumerator(manager)
        val backLogical = enumerator.logicalCameras().firstOrNull { it.facing == "back" }
          ?: enumerator.logicalCameras().firstOrNull()
        if (backLogical == null) {
          promise.reject("ERR_NO_CAMERA", "No rear camera available")
          return@Thread
        }
        val sessionDir = File(reactContext.filesDir, "captures/${UUID.randomUUID()}")
        sessionDir.mkdirs()
        val originalsDir = File(sessionDir, "originals").apply { mkdirs() }

        val physicalIds = backLogical.physicalIds.take(MAX_CONCURRENT_PHYSICAL)
        val usedIds: List<String>
        val mode: String
        val jpegById: Map<String, ByteArray>

        if (backLogical.supportsConcurrent && physicalIds.size >= 2) {
          // True simultaneous capture: one logical camera, one capture request,
          // N surfaces each bound to a physical camera id via OutputConfiguration.
          try {
            val out = ConcurrentCaptureController(reactContext, manager, backLogical, physicalIds).capture()
            jpegById = out
            usedIds = physicalIds
            mode = "concurrent"
          } catch (t: Throwable) {
            // HAL refused (OEM-specific). Fall back to sequential — explicitly reported.
            Log.w(NAME, "Concurrent capture failed, falling back to sequential", t)
            val out = SequentialCaptureController(reactContext, manager, backLogical).capture()
            jpegById = out
            usedIds = out.keys.toList()
            mode = "sequential"
          }
        } else {
          val out = SequentialCaptureController(reactContext, manager, backLogical).capture()
          jpegById = out
          usedIds = out.keys.toList()
          mode = "sequential"
        }

        val originalPaths = Arguments.createArray()
        for ((camId, jpeg) in jpegById) {
          val f = File(originalsDir, "cam_${camId}.jpg")
          f.writeBytes(jpeg)
          originalPaths.pushString(f.absolutePath)
        }

        var mergedPath: String? = null
        if (mergeMode != "none" && jpegById.size >= 2) {
          val paths = jpegById.entries.sortedBy { it.key }.map { it.value }.let { bytes ->
            // stitch needs file paths; write all then stitch
            emptyList<String>()
          }
          val files = jpegById.entries.sortedBy { it.key }.map { (camId, _) ->
            File(originalsDir, "cam_${camId}.jpg").absolutePath
          }
          mergedPath = ImageStitcher.stitch(reactContext, files, mergeMode, quality)
        }

        val map = Arguments.createMap().apply {
          putString("mode", mode)
          putString("logicalCameraId", backLogical.id)
          putArray("cameraIds", Arguments.fromList(usedIds))
          putArray("originals", originalPaths)
          if (mergedPath != null) putString("merged", mergedPath) else putNull("merged")
          putString("sessionDir", sessionDir.absolutePath)
        }
        promise.resolve(map)
      } catch (t: Throwable) {
        Log.e(NAME, "capture failed", t)
        promise.reject("ERR_CAPTURE", t.message, t)
      }
    }.start()
  }

  @ReactMethod
  fun mergeImages(paths: ReadableArray, mode: String, promise: Promise) {
    Thread {
      try {
        val list = (0 until paths.size()).map { paths.getString(it)!! }
        if (list.size < 2) {
          promise.reject("ERR_MERGE", "Need at least 2 images to merge")
          return@Thread
        }
        val out = ImageStitcher.stitch(reactContext, list, mode, 92)
        promise.resolve(out)
      } catch (t: Throwable) {
        Log.e(NAME, "mergeImages failed", t)
        promise.reject("ERR_MERGE", t.message, t)
      }
    }.start()
  }

  companion object {
    const val NAME = "MultiShotFusionModule"
    // Camera2/CDD guarantees only "replace one logical stream with two physical streams".
    // We therefore attempt at most 2 truly concurrent physical captures; any further
    // cameras are captured sequentially. This is a hard hardware guarantee, not a policy.
    const val MAX_CONCURRENT_PHYSICAL = 2
  }
}
