
package com.multishotfusion.camera

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Sequential fallback: captures one physical camera at a time through the same
 * logical camera. Used when concurrent capture is unavailable or refused by the
 * HAL. The capture mode is always reported truthfully to JS.
 */
class SequentialCaptureController(
  private val context: Context,
  private val manager: CameraManager,
  private val logical: CameraInfoNative,
) {
  private val thread = HandlerThread("msf-sequential").apply { start() }
  private val handler = Handler(thread.looper)

  fun capture(): Map<String, ByteArray> {
    val enumerator = CameraEnumerator(manager)
    val size = enumerator.maxJpegSize(logical.id)
    // Capture each advertised physical camera if the HAL exposes them; otherwise the logical camera itself.
    val targets = if (logical.physicalIds.isNotEmpty()) logical.physicalIds else listOf(logical.id)
    val results = mutableMapOf<String, ByteArray>()

    for (target in targets) {
      val reader = ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 1)
      val frameLatch = CountDownLatch(1)
      var bytes: ByteArray? = null
      reader.setOnImageAvailableListener({ r ->
        try {
          r.acquireLatestImage()?.use { img ->
            val buf = img.planes[0].buffer
            bytes = ByteArray(buf.remaining()).also { buf.get(it) }
          }
        } finally { frameLatch.countDown() }
      }, handler)

      val openLatch = CountDownLatch(1)
      var device: CameraDevice? = null
      var openError: Throwable? = null
      manager.openCamera(logical.id, handler, object : CameraDevice.StateCallback() {
        override fun onOpened(d: CameraDevice) { device = d; openLatch.countDown() }
        override fun onDisconnected(d: CameraDevice) { d.close(); openError = RuntimeException("Camera disconnected"); openLatch.countDown() }
        override fun onError(d: CameraDevice, error: Int) { d.close(); openError = RuntimeException("Camera error $error"); openLatch.countDown() }
      })
      if (!openLatch.await(5, TimeUnit.SECONDS) || device == null) {
        reader.close(); throw openError ?: RuntimeException("Timeout opening camera")
      }

      val configured = CountDownLatch(1)
      var session: CameraCaptureSession? = null
      var configError: Throwable? = null
      val oc = OutputConfiguration(reader.surface).apply {
        if (target != logical.id && Build.VERSION.SDK_INT >= 28) setPhysicalCameraId(target)
      }
      val sc = SessionConfiguration(
        SessionConfiguration.SESSION_REGULAR, listOf(oc),
        { it.run() },
        object : CameraCaptureSession.StateCallback() {
          override fun onConfigured(s: CameraCaptureSession) { session = s; configured.countDown() }
          override fun onConfigureFailed(s: CameraCaptureSession) {
            configError = RuntimeException("Session configuration failed for $target")
            configured.countDown()
          }
        })
      device!!.createCaptureSession(sc)
      if (!configured.await(5, TimeUnit.SECONDS) || session == null) {
        device!!.close(); reader.close(); throw configError ?: RuntimeException("Timeout configuring session")
      }

      val captured = CountDownLatch(1)
      var failed = false
      val req = device!!.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
        addTarget(reader.surface)
        set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        set(CaptureRequest.JPEG_ORIENTATION, enumerator.sensorOrientation(logical.id))
      }.build()
      session!!.capture(req, object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: android.hardware.camera2.TotalCaptureResult) { captured.countDown() }
        override fun onCaptureFailed(s: CameraCaptureSession, r: CaptureRequest, f: android.hardware.camera2.CaptureFailure) { failed = true; captured.countDown() }
      }, handler)
      captured.await(8, TimeUnit.SECONDS)
      frameLatch.await(4, TimeUnit.SECONDS)

      try { session?.close() } catch (_: Throwable) {}
      device!!.close()
      reader.close()

      if (failed || bytes == null) throw RuntimeException("Sequential capture failed for $target")
      results[target] = bytes!!
    }
    thread.quitSafely()
    return results
  }
}
