
import React from 'react';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StatusBar } from 'expo-status-bar';
import { Text } from 'react-native';
import CameraScreen from './src/screens/CameraScreen';
import GalleryScreen from './src/screens/GalleryScreen';
import EditorScreen from './src/screens/EditorScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import { colors } from './src/theme';

const Stack = createNativeStackNavigator();
const Tabs = createBottomTabNavigator();

const navTheme = { ...DarkTheme, colors: { ...DarkTheme.colors, background: colors.bg, card: colors.surface, primary: colors.accent, text: colors.text, border: colors.border } };

function GalleryStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg } }}>
      <Stack.Screen name="Gallery" component={GalleryScreen} />
      <Stack.Screen name="Editor" component={EditorScreen} />
    </Stack.Navigator>
  );
}

function tabIcon(label: string) {
  return function Icon({ focused, color, size }: any) {
    const glyph = label === 'Camera' ? '◎' : label === 'Rolls' ? '▦' : '⚙';
    return <Text style={{ fontSize: size, color: focused ? colors.accent : color }}>{glyph}</Text>;
  };
}

export default function App() {
  return (
    <NavigationContainer theme={navTheme}>
      <StatusBar style="light" />
      <Tabs.Navigator screenOptions={{ headerShown: false, tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border } }}>
        <Tabs.Screen name="Camera" component={CameraScreen} options={{ tabBarIcon: tabIcon('Camera') }} />
        <Tabs.Screen name="Rolls" component={GalleryStack} options={{ tabBarIcon: tabIcon('Rolls') }} />
        <Tabs.Screen name="Settings" component={SettingsScreen} options={{ tabBarIcon: tabIcon('Settings') }} />
      </Tabs.Navigator>
    </NavigationContainer>
  );
}
