
// Expo config plugin: installs the MultiShotFusion native Camera2 module.
// - Copies Kotlin sources from native-android/ into the android project
// - Registers the ReactPackage in MainApplication
// - Ensures manifest permissions (CAMERA) are present
const { withDangerousMod, withAndroidManifest, withMainApplication } = require('expo/config-plugins');
const fs = require('fs');
const path = require('path');

const PKG_DIR = 'com/multishotfusion/camera';

const withMultiShotFusion = (config) => {
  config = withDangerousMod(config, [
    'android',
    async (cfg) => {
      const projectRoot = cfg.modRequest.projectRoot;
      const srcRoot = path.join(projectRoot, 'native-android', 'java', PKG_DIR);
      const destRoot = path.join(projectRoot, 'android', 'app', 'src', 'main', 'java', PKG_DIR);
      fs.mkdirSync(destRoot, { recursive: true });
      for (const file of fs.readdirSync(srcRoot)) {
        if (file.endsWith('.kt')) {
          fs.copyFileSync(path.join(srcRoot, file), path.join(destRoot, file));
        }
      }
      return cfg;
    },
  ]);

  config = withMainApplication(config, (cfg) => {
    const src = cfg.modResults.contents;
    const anchor = 'add(';
    // Generated MainApplication contains: PackageList(this).packages.apply { ... add() comment ... }
    if (!src.includes('MultiShotFusionPackage')) {
      cfg.modResults.contents = src.replace(
        /(\/\/ Packages that cannot be autolinked yet[\s\S]*?)(?=\s*\})/,
        (m) => m + '\n      add(com.multishotfusion.camera.MultiShotFusionPackage())'
      );
    }
    return cfg;
  });

  config = withAndroidManifest(config, (cfg) => {
    const manifest = cfg.modResults.manifest;
    const perms = [
      'android.permission.CAMERA',
      'android.permission.WRITE_EXTERNAL_STORAGE',
      'android.permission.READ_EXTERNAL_STORAGE',
    ];
    const existing = new Set(
      (manifest['uses-permission'] || []).map((p) => p.$['android:name'])
    );
    manifest['uses-permission'] = manifest['uses-permission'] || [];
    for (const name of perms) {
      if (!existing.has(name)) {
        manifest['uses-permission'].push({
          $: {
            'android:name': name,
            ...(name.includes('EXTERNAL_STORAGE')
              ? { 'android:maxSdkVersion': '28' }
              : {}),
          },
        });
      }
    }
    return cfg;
  });

  return config;
};

module.exports = withMultiShotFusion;
